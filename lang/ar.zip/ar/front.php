<?php

return [
    'internship-apply' => 'Internship Apply',
    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'email' => 'Email',
    'date_of_birth' => 'Date of birth',
    'phone_number' => 'Phone Number',
    'cv' => 'CV',
    'only' => 'Only',
    'apply' => 'Apply',
    'internship_request_sent' => 'We have received your internship request',
    'ok' => 'Ok',
];